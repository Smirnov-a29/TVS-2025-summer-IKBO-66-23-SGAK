package com.example.myapplication.model;

public class User {
    public static String currentUser = null;
}
